-- -----------------------------
-- Haidao MySQL Data Transfer 
-- author admin@nbnat.com 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2018-07-11 10:29:14
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `nc_cms_article`
-- -----------------------------
DROP TABLE IF EXISTS `nc_cms_article`;
CREATE TABLE `nc_cms_article` (
  `article_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章编号',
  `title` varchar(50) NOT NULL COMMENT '文章标题',
  `class_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章分类编号',
  `short_title` varchar(50) NOT NULL DEFAULT '' COMMENT '文章短标题',
  `source` varchar(50) NOT NULL DEFAULT '' COMMENT '文章来源',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '文章来源链接',
  `author` varchar(50) NOT NULL COMMENT '文章作者',
  `summary` varchar(140) NOT NULL DEFAULT '' COMMENT '文章摘要',
  `content` text NOT NULL COMMENT '文章正文',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '文章标题图片',
  `keyword` varchar(255) NOT NULL DEFAULT '' COMMENT '文章关键字',
  `article_id_array` varchar(255) NOT NULL DEFAULT '' COMMENT '相关文章',
  `click` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章点击量',
  `sort` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '文章排序0-255',
  `commend_flag` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '文章推荐标志0-未推荐，1-已推荐',
  `comment_flag` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '文章是否允许评论1-允许，0-不允许',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '0-草稿、1-待审核、2-已发布、-1-回收站',
  `attachment_path` text NOT NULL COMMENT '文章附件路径',
  `tag` varchar(255) NOT NULL DEFAULT '' COMMENT '文章标签',
  `comment_count` int(10) unsigned NOT NULL COMMENT '文章评论数',
  `share_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章分享数',
  `publisher_name` varchar(50) NOT NULL COMMENT '发布者用户名 ',
  `uid` int(10) unsigned NOT NULL COMMENT '发布者编号',
  `last_comment_time` int(11) DEFAULT '0' COMMENT '最新评论时间',
  `public_time` int(11) DEFAULT '0' COMMENT '发布时间',
  `create_time` int(11) DEFAULT '0' COMMENT '文章发布时间',
  `modify_time` int(11) DEFAULT '0' COMMENT '文章修改时间',
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=6553 COMMENT='CMS文章表';

-- -----------------------------
-- Records of `nc_cms_article`
-- -----------------------------
INSERT INTO `nc_cms_article` VALUES ('1', '井柏然倪妮结束2年半恋情 私下约会甜蜜接地气', '2', '井柏然倪妮结束2年半恋情', '', 'http://localhost/shopping9/index.php?s=/admin/cms/addarticle', '高剑离', '', '<p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">6月中旬，在某电影节晚宴上，之前一直在晚宴形影不离的井柏然与倪妮此次晚宴却意外没有&quot;合体&quot;，且全程无交流。</p><p class="content-img" style="margin-top: 1.8em; margin-bottom: 30px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; text-align: justify; white-space: normal; background-color: rgb(255, 255, 255);"><img src="https://p4.ssl.cdn.btime.com/t01e9611da18b6816be.jpg?size=630x945" style="margin: 0px auto; padding: 0px; border: 0px; vertical-align: middle; display: block; max-width: 100%; word-wrap: break-word !important;"/></p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">井柏然、倪妮</p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">7月5日，井柏然、倪妮工作室同时在微博发声明宣布，经双方经慎重考虑，两人于今年5月和平分手。未来将以朋友的身份真诚祝福彼此，今后将不对此事做任何回应。此外，井柏然方另发声明否认两人是&quot;合约情侣&quot;，谴责恶意造谣的行为，要求立即删除否则将法律追责。倪妮方则在另一条声明中否认与胡某在一起及炒作恋情。</p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">倪妮与井柏然二人于2013年因拍摄电影《等风来》相识，不过当时的倪妮尚有男友冯绍峰[微博]。在当时的某次采访中，井柏然曾直言羡慕倪妮和冯绍峰的感情。对此倪妮笑称&quot;让井柏然早点下手，不然好的都被挑走了&quot;。</p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">而自倪妮、冯绍峰和平分手后，2016年，倪妮、井柏然两人被拍到共同度夜。之后，倪妮大方承认了恋情。同时双方经纪人宣布:&quot;两人从2016年春节开始尝试交往，希望大家可以给双方一些空间，多多祝福。&quot;</p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">自公开恋情后，这对情侣一直十分低调。少数几次共同亮相多为众星云集的晚会或时尚杂志拍摄活动。虽然如此，但他们的每次&quot;合体&quot;必引网友直呼&quot;男才女貌，配一脸!&quot;</p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">此外，这对小情侣私下生活似也颇为甜蜜，烟火气十足。被拍到的场景多为一起逛超市、买衣服等生活场景。在去年的第三季《花儿与少年》中，倪妮在井柏然家里露出的&quot;惊鸿一瞥&quot;则是在井柏然出发前两人接吻告别，被观众直呼&quot;甜蜜爆表&quot;。</p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">不过近来，两人&quot;疑似分手&quot;类新闻不断，有心的网友也总结了各类蛛丝马迹。今年5月，疑似两人的游戏账号换掉了情侣头像，同时井柏然退出了倪妮战队。6月中旬，在某电影节晚宴上，之前一直在晚宴形影不离的他们此次晚宴却意外没有&quot;合体&quot;，且全程无交流。而在井柏然在近期参加巴黎时尚活动时，也有眼尖的网友从照片中发现井柏然似乎戴上了尾戒。众所周知，尾戒的含义即为单身。但&quot;分手&quot;传闻并未得到当事人回应。</p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; text-indent: 2em; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">而就在今日(7月5日)，井柏然、倪妮工作室同时在微博发声明宣布，经双方经慎重考虑，两人于今年5月和平分手。未来将以朋友的身份真诚祝福彼此，今后将不对此事做任何回应。</p><p><br/></p>', 'upload/common/1530840458.jpg', '', '', '0', '0', '1', '1', '2', '', '井柏然倪妮结束2年半恋情', '0', '0', 'admin', '2', '0', '1530840514', '1530840514', '0');
INSERT INTO `nc_cms_article` VALUES ('2', '娱乐圈的烂演员终于被公布了！演员也要有工匠精神！', '4', '演员也要有工匠精神！', '娱乐', 'https://item.btime.com/31tovsdjgbq9kv8p9cej1tgf14i?from=haoz1t2p1', '未知', '第一名是杨幂老公刘恺威，电视剧作品全都低于六分..也实在尴尬。而作为少女杀手的鹿晗在最后一名。看来观众的眼睛还是雪亮的！', '<p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">如今娱乐圈的风头可谓全被小鲜肉小花旦给抢了，而真正的有本事的有演技的都被渐渐遗忘。不是不能接受新事物，而是这些人得演技实在让人恭维啊！拿着几千万甚至上亿的片酬，一个比一个叫的凶猛！可是留给观众的却是不堪入目的作品！</p><p class="content-img" style="margin-top: 1.8em; margin-bottom: 30px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; text-align: justify; white-space: normal; background-color: rgb(255, 255, 255);"><img src="https://p3.ssl.cdn.btime.com/t0191b7d436e5b1f575.jpg?size=640x359" style="margin: 0px auto; padding: 0px; border: 0px; vertical-align: middle; display: block; max-width: 100%; word-wrap: break-word !important;"/></p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">在战狼2之后，不少人为其撑场面，其因就是因为这部影片演出了真正地好作品！而近日广电统计了一份关于演艺圈内演员烂剧的排行榜，许多小鲜肉和小花旦们被点名，更让这些人被人们熟知！</p><p class="content-img" style="margin-top: 1.8em; margin-bottom: 30px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; text-align: justify; white-space: normal; background-color: rgb(255, 255, 255);"><img src="https://p3.ssl.cdn.btime.com/t01ad03c8df95d764a1.jpg?size=580x716" style="margin: 0px auto; padding: 0px; border: 0px; vertical-align: middle; display: block; max-width: 100%; word-wrap: break-word !important;"/></p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">第一名是杨幂老公刘恺威，电视剧作品全都低于六分..也实在尴尬。而作为少女杀手的鹿晗在最后一名。看来观众的眼睛还是雪亮的！</p><p class="content-img" style="margin-top: 1.8em; margin-bottom: 30px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; text-align: justify; white-space: normal; background-color: rgb(255, 255, 255);"><img src="https://p3.ssl.cdn.btime.com/t01fc72c53006840831.jpg?size=640x421" style="margin: 0px auto; padding: 0px; border: 0px; vertical-align: middle; display: block; max-width: 100%; word-wrap: break-word !important;"/></p><p style="margin-top: 1.8em; margin-bottom: 0px; padding: 0px; color: rgb(51, 51, 51); font-family: &quot;Microsoft Yahei&quot;, &quot;Hiragino Sans GB&quot;, 宋体; white-space: normal; background-color: rgb(255, 255, 255);">如若中国的影视圈都是充满了毫无演技，只靠颜值的小鲜肉的话，那想要如国力一样赶超其他国家那真不知道要到什么时候，虽说在当今这个社会，颜值被默认为一项财富。但印度的阿米尔汗可谓是印度影视界的国宝级人物啊，他在拍摄一部电影爆瘦爆增，我们中国也并不是没有，可是真正有才华的都被这些小鲜肉抢了机会！工匠精神同样可以适用于任何一个行业啊！而在娱乐圈真正具有这样精神的人被遗弃，广电也早该整治一下了，还娱乐圈一片清净，对此，你有什么想说的呢？</p><p><br/></p>', 'upload/common/1531275757.jpg', '娱乐圈', '', '3', '0', '1', '1', '2', '', '演员', '5', '5', 'admin', '2', '0', '1531275830', '1531275830', '0');

-- -----------------------------
-- Table structure for `nc_cms_article_class`
-- -----------------------------
DROP TABLE IF EXISTS `nc_cms_article_class`;
CREATE TABLE `nc_cms_article_class` (
  `class_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类编号 ',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '上级分类',
  `name` varchar(50) NOT NULL COMMENT '分类名称',
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1170 COMMENT='cms文章分类表';

-- -----------------------------
-- Records of `nc_cms_article_class`
-- -----------------------------
INSERT INTO `nc_cms_article_class` VALUES ('1', '0', '生活', '0');
INSERT INTO `nc_cms_article_class` VALUES ('2', '0', '奇问异事', '0');
INSERT INTO `nc_cms_article_class` VALUES ('3', '1', '教育', '0');
INSERT INTO `nc_cms_article_class` VALUES ('4', '1', '琐事', '0');
